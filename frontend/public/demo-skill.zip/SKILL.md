---
name: demo-skill
description: 这是一个示例技能，展示技能包的标准结构和格式
---

# 示例技能

这是一个演示用的技能包，帮助你了解如何创建自己的技能。

## 使用场景

- 当用户需要了解技能包的格式时，可以参考此示例
- 当用户需要创建新技能时，可以基于此模板修改

## 技能说明

此技能包含以下文件结构：

- `SKILL.md` — 必需，技能描述文件（即本文件）
- `scripts/` — 可选，存放脚本文件
- `references/` — 可选，存放参考文档
- `requirements.txt` — 可选，Python 依赖声明

## 注意事项

1. `SKILL.md` 是必需文件，其中 YAML front-matter 的 `name` 字段必须是小写字母、数字和连字符
2. `description` 字段应简短描述技能功能
3. 脚本文件放在 `scripts/` 目录下
4. 参考文档放在 `references/` 目录下
5. 整个技能包需要打包为 zip 文件上传
