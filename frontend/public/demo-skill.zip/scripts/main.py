#!/usr/bin/env python3
"""示例技能脚本 - 数据处理工具"""


def process_data(data: str) -> dict:
    """处理输入数据并返回结构化结果。

    Args:
        data: 输入的原始数据字符串

    Returns:
        包含处理结果的字典
    """
    lines = data.strip().split("\n")
    result = {
        "total_lines": len(lines),
        "total_chars": sum(len(line) for line in lines),
        "non_empty_lines": sum(1 for line in lines if line.strip()),
    }
    return result


if __name__ == "__main__":
    sample = """第一行数据
第二行数据

第四行数据（第三行为空行）
"""
    print(process_data(sample))
