# 技能开发指南

## 创建技能包的步骤

1. 创建一个目录，以技能名称命名（小写字母、数字和连字符）
2. 在目录根创建 `SKILL.md` 文件，包含 YAML front-matter
3. 按需添加 `scripts/`、`references/` 等子目录
4. 将整个目录打包为 zip 文件
5. 通过界面上传 zip 文件

## SKILL.md 格式说明

```markdown
---
name: your-skill-name
description: 简短描述此技能的功能
---

# 技能标题

技能的详细说明...
```

## 命名规范

- 技能名称：小写字母、数字和连字符，如 `my-skill-name`
- 描述：简短明了，不超过 200 字
- 文件数量：单个技能包不超过 20 个文件
- 文件大小：单个文件不超过 20MB
